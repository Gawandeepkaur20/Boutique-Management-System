import { useEffect, useState } from 'react';
import api from '../../services/api';

const FIELDS = [
  { key: 'height', label: 'Height (cm)' },
  { key: 'chest', label: 'Chest (in)' },
  { key: 'waist', label: 'Waist (in)' },
  { key: 'shoulder', label: 'Shoulder (in)' },
  { key: 'sleeveLength', label: 'Sleeve Length (in)' },
  { key: 'hip', label: 'Hip (in)' },
  { key: 'neck', label: 'Neck (in)' },
  { key: 'inseam', label: 'Inseam (in)' },
];

export default function CustomerMeasurements() {
  const [measurements, setMeasurements] = useState([]);
  const [form, setForm] = useState({});
  const [additional, setAdditional] = useState({ key: '', value: '' });

  const load = async () => {
    const profile = await api.get('/customers/profile');
    const customerId = profile.data.customer._id;
    const { data } = await api.get(`/measurements/customer/${customerId}`);
    setMeasurements(data);
  };

  useEffect(() => { load(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const additionalMeasurements = {};
    if (additional.key) additionalMeasurements[additional.key] = Number(additional.value);
    await api.post('/measurements', { ...form, additionalMeasurements, isDefault: true });
    setForm({});
    load();
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <h1 className="text-2xl font-bold">Measurements</h1>

      <form onSubmit={handleSubmit} className="card">
        <h2 className="font-semibold mb-4">New Measurement</h2>
        <div className="grid grid-cols-2 gap-4">
          {FIELDS.map(({ key, label }) => (
            <div key={key}>
              <label className="block text-sm mb-1">{label}</label>
              <input type="number" step="0.1" className="input-field" value={form[key] || ''}
                onChange={(e) => setForm({ ...form, [key]: Number(e.target.value) })} />
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4 mt-4">
          <input className="input-field" placeholder="Additional field name" value={additional.key}
            onChange={(e) => setAdditional({ ...additional, key: e.target.value })} />
          <input type="number" className="input-field" placeholder="Value" value={additional.value}
            onChange={(e) => setAdditional({ ...additional, value: e.target.value })} />
        </div>
        <textarea className="input-field mt-4" rows={2} placeholder="Notes" value={form.notes || ''}
          onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        <button type="submit" className="btn-primary mt-4">Save Measurements</button>
      </form>

      <div className="card">
        <h2 className="font-semibold mb-4">Saved Measurements</h2>
        {measurements.map((m) => (
          <div key={m._id} className="p-4 mb-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <p className="text-sm text-gray-500 mb-2">{new Date(m.createdAt).toLocaleString()}</p>
            <div className="grid grid-cols-4 gap-2 text-sm">
              {FIELDS.map(({ key, label }) => m[key] != null && (
                <div key={key}><span className="text-gray-500">{label.split(' ')[0]}:</span> {m[key]}</div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
