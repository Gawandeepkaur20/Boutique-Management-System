import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Ruler, Search } from 'lucide-react';
import StatCard from '../../components/StatCard';
import OnboardingHint from '../../components/OnboardingHint';
import { StatCardSkeleton } from '../../components/Skeleton';
import StatusBadge from '../../components/StatusBadge';
import api from '../../services/api';

export default function CustomerDashboard() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/orders/my').then((r) => setOrders(r.data || [])).finally(() => setLoading(false));
  }, []);

  const active = orders.filter((o) => o.status !== 'delivered').length;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      <OnboardingHint id="customer-dashboard">
        Welcome! Update your measurements, upload design references in Profile, and track orders here.
      </OnboardingHint>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <StatCardSkeleton key={i} />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard title="Total Orders" value={orders.length} icon={ShoppingBag} color="primary" />
          <StatCard title="Active Orders" value={active} icon={Search} color="orange" />
          <StatCard title="Delivered" value={orders.length - active} icon={ShoppingBag} color="green" />
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-4">
        <Link to="/customer/measurements" className="card hover:shadow-md transition-shadow flex items-center gap-3">
          <Ruler className="w-8 h-8 text-primary-600" />
          <div>
            <p className="font-semibold">Measurements</p>
            <p className="text-sm text-gray-500">Add or update your sizes</p>
          </div>
        </Link>
        <Link to="/customer/track" className="card hover:shadow-md transition-shadow flex items-center gap-3">
          <Search className="w-8 h-8 text-primary-600" />
          <div>
            <p className="font-semibold">Track Order</p>
            <p className="text-sm text-gray-500">Check order status</p>
          </div>
        </Link>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-4">Recent Orders</h2>
        {orders.length === 0 ? (
          <p className="text-gray-500 text-sm">No orders yet.</p>
        ) : (
          <ul className="space-y-3">
            {orders.slice(0, 5).map((o) => (
              <li key={o._id} className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700 last:border-0">
                <span className="font-medium">{o.orderNumber}</span>
                <StatusBadge status={o.status} />
              </li>
            ))}
          </ul>
        )}
        <Link to="/customer/orders" className="text-primary-600 text-sm mt-4 inline-block hover:underline">
          View all orders →
        </Link>
      </div>
    </div>
  );
}
