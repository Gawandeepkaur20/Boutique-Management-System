import { useEffect, useState } from 'react';
import StatusBadge from '../../components/StatusBadge';
import DataTable from '../../components/DataTable';
import api from '../../services/api';

export default function CustomerOrders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    api.get('/orders/my').then((r) => setOrders(r.data || []));
  }, []);

  const columns = [
    { field: 'orderNumber', headerName: 'Order #' },
    { field: 'status', headerName: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { field: 'totalAmount', headerName: 'Total', render: (r) => `₹${r.totalAmount}` },
    { field: 'items', headerName: 'Items', render: (r) => r.items?.map((i) => i.name).join(', ') },
    { field: 'deliveryDate', headerName: 'Delivery', render: (r) => r.deliveryDate ? new Date(r.deliveryDate).toLocaleDateString() : '—' },
    { field: 'createdAt', headerName: 'Ordered', render: (r) => new Date(r.createdAt).toLocaleDateString() },
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Order History</h1>
      <div className="card">
        <DataTable columns={columns} rows={orders} />
      </div>
    </div>
  );
}
