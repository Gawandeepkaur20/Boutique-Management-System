import { useEffect, useState } from 'react';
import { Upload, Plus } from 'lucide-react';
import { Alert } from '@mui/material';
import api from '../../services/api';

export default function CustomerProfile() {
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState({});
  const [modForm, setModForm] = useState({ title: '', description: '' });
  const [message, setMessage] = useState('');

  const load = () => {
    api.get('/customers/profile').then((r) => {
      setProfile(r.data);
      const c = r.data.customer;
      setForm({
        name: c.user?.name,
        phone: c.user?.phone,
        address: c.address,
        city: c.city,
        state: c.state,
        zipCode: c.zipCode,
        notes: c.notes,
      });
    });
  };

  useEffect(() => { load(); }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    await api.put('/customers/profile', form);
    setMessage('Profile updated!');
    load();
  };

  const handleUpload = async (e) => {
    const files = e.target.files;
    if (!files?.length) return;
    const fd = new FormData();
    Array.from(files).forEach((f) => fd.append('images', f));
    await api.post('/customers/reference-images', fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    load();
  };

  const addModification = async () => {
    await api.post('/customers/modifications', modForm);
    setModForm({ title: '', description: '' });
    load();
  };

  if (!profile) return <div>Loading...</div>;

  return (
    <div className="space-y-6 max-w-3xl">
      <h1 className="text-2xl font-bold">My Profile</h1>
      {message && <Alert severity="success" onClose={() => setMessage('')}>{message}</Alert>}

      <form onSubmit={handleSave} className="card space-y-4">
        <h2 className="font-semibold">Personal Details</h2>
        {['name', 'phone', 'address', 'city', 'state', 'zipCode'].map((f) => (
          <div key={f}>
            <label className="block text-sm font-medium mb-1 capitalize">{f}</label>
            <input className="input-field" value={form[f] || ''}
              onChange={(e) => setForm({ ...form, [f]: e.target.value })} />
          </div>
        ))}
        <textarea className="input-field" rows={3} placeholder="Notes" value={form.notes || ''}
          onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        <button type="submit" className="btn-primary">Save Profile</button>
      </form>

      <div className="card">
        <h2 className="font-semibold mb-4">Reference Images / Designs</h2>
        <label className="btn-secondary inline-flex items-center gap-2 cursor-pointer">
          <Upload className="w-4 h-4" /> Upload Images
          <input type="file" multiple accept="image/*" className="hidden" onChange={handleUpload} />
        </label>
        <div className="grid grid-cols-3 gap-3 mt-4">
          {profile.customer?.referenceImages?.map((img, i) => (
            <img key={i} src={img.url} alt="reference" className="rounded-lg h-24 object-cover" />
          ))}
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-4">Modification Requests</h2>
        <div className="flex gap-2 mb-4">
          <input className="input-field" placeholder="Title" value={modForm.title}
            onChange={(e) => setModForm({ ...modForm, title: e.target.value })} />
          <input className="input-field" placeholder="Description" value={modForm.description}
            onChange={(e) => setModForm({ ...modForm, description: e.target.value })} />
          <button type="button" onClick={addModification} className="btn-primary">
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <ul className="space-y-2">
          {profile.customer?.modificationRequests?.map((m, i) => (
            <li key={i} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <p className="font-medium">{m.title}</p>
              <p className="text-sm text-gray-500">{m.description}</p>
              <span className="text-xs capitalize text-primary-600">{m.status}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
