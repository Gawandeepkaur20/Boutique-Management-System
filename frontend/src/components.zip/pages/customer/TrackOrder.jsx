import { useState } from 'react';
import { Search } from 'lucide-react';
import StatusBadge from '../../components/StatusBadge';
import api from '../../services/api';

const STEPS = ['received', 'processing', 'stitching', 'ready', 'delivered'];

export default function CustomerTrackOrder() {
  const [orderNumber, setOrderNumber] = useState('');
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');

  const track = async () => {
    setError('');
    try {
      const { data } = await api.get(`/orders/track/${orderNumber}`);
      setOrder(data);
    } catch {
      setError('Order not found');
      setOrder(null);
    }
  };

  const currentStep = order ? STEPS.indexOf(order.status) : -1;

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-2xl font-bold">Track Order</h1>

      <div className="card flex gap-3">
        <input className="input-field flex-1" placeholder="Enter order number (e.g. ORD-00001)"
          value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} />
        <button onClick={track} className="btn-primary flex items-center gap-2">
          <Search className="w-4 h-4" /> Track
        </button>
      </div>

      {error && <p className="text-red-500">{error}</p>}

      {order && (
        <div className="card space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-xl font-bold">{order.orderNumber}</h2>
              <p className="text-gray-500">Placed {new Date(order.createdAt).toLocaleDateString()}</p>
            </div>
            <StatusBadge status={order.status} />
          </div>

          <div className="flex justify-between relative">
            <div className="absolute top-4 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-600" />
            {STEPS.map((step, i) => (
              <div key={step} className="relative flex flex-col items-center z-10">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  i <= currentStep ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-600 text-gray-500'
                }`}>
                  {i + 1}
                </div>
                <span className="text-xs mt-2 capitalize text-center w-16">{step}</span>
              </div>
            ))}
          </div>

          <div>
            <h3 className="font-semibold mb-2">Items</h3>
            {order.items?.map((item, i) => (
              <div key={i} className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span>{item.name} x{item.quantity}</span>
                <span>₹{item.price * item.quantity}</span>
              </div>
            ))}
            <p className="font-bold mt-2 text-right">Total: ₹{order.totalAmount}</p>
          </div>
        </div>
      )}
    </div>
  );
}
