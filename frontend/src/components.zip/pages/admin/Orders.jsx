import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Download, Search, Upload } from 'lucide-react';
import { Dialog, DialogTitle, DialogContent } from '@mui/material';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import EmptyState from '../../components/EmptyState';
import OrderFormDialog from '../../components/OrderFormDialog';
import { TableSkeleton } from '../../components/Skeleton';
import api from '../../services/api';
import { showSuccess, showError } from '../../utils/toast';

const STATUSES = ['received', 'processing', 'stitching', 'ready', 'delivered'];
const defaultForm = {
  customerId: '', items: [{ name: '', quantity: 1, price: 0, fabric: '' }],
  priority: 'medium', advancePaid: 0, deliveryDate: '', notes: '',
};

export default function AdminOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [workers, setWorkers] = useState([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [assignOpen, setAssignOpen] = useState(null);
  const [importOpen, setImportOpen] = useState(false);
  const [form, setForm] = useState(defaultForm);

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (statusFilter) params.set('status', statusFilter);
    if (search) params.set('search', search);
    api.get(`/orders?${params}`)
      .then((res) => setOrders(res.data.orders || []))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get('/customers').then((r) => setCustomers(r.data.customers || []));
    api.get('/workers').then((r) => setWorkers(r.data || []));
  }, [statusFilter]);

  const handleCreate = async () => {
    try {
      await api.post('/orders', form);
      showSuccess('Order created successfully');
      setOpen(false);
      setForm(defaultForm);
      load();
    } catch (err) {
      showError(err.response?.data?.message || 'Failed to create order');
    }
  };

  const updateStatus = async (id, status) => {
    await api.patch(`/orders/${id}/status`, { status });
    showSuccess('Status updated');
    load();
  };

  const assignWorker = async (orderId, workerId) => {
    await api.patch(`/orders/${orderId}/assign`, { workerId });
    showSuccess('Worker assigned');
    setAssignOpen(null);
    load();
  };

  const generateInvoice = async (id) => {
    try {
      await api.post(`/orders/${id}/invoice`);
      showSuccess('Invoice generated and email sent');
    } catch {
      showError('Failed to generate invoice');
    }
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const { data } = await api.post('/export/import/orders', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      showSuccess(`Imported preview: ${data.rowCount} rows`);
      setImportOpen(false);
    } catch {
      showError('Import failed');
    }
  };

  const columns = [
    {
      field: 'orderNumber', headerName: 'Order #',
      render: (r) => (
        <button className="text-primary-600 hover:underline font-medium" onClick={() => navigate(`/admin/orders/${r._id}`)}>
          {r.orderNumber}
        </button>
      ),
    },
    { field: 'customer', headerName: 'Customer', render: (r) => r.customer?.user?.name },
    { field: 'status', headerName: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { field: 'worker', headerName: 'Worker', render: (r) => r.worker?.user?.name || '—' },
    { field: 'totalAmount', headerName: 'Total', render: (r) => `₹${r.totalAmount}` },
    { field: 'createdAt', headerName: 'Date', render: (r) => new Date(r.createdAt).toLocaleDateString() },
    {
      field: 'actions', headerName: 'Actions', sortable: false,
      render: (r) => (
        <div className="flex gap-1 flex-wrap">
          <select className="text-xs border rounded px-1 dark:bg-gray-800" value={r.status}
            onChange={(e) => updateStatus(r._id, e.target.value)}>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <button className="text-xs text-primary-600" onClick={() => setAssignOpen(r._id)}>Assign</button>
          <button className="text-xs text-green-600" onClick={() => generateInvoice(r._id)}>Bill</button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <h1 className="text-2xl font-bold">Orders</h1>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setImportOpen(true)} className="btn-secondary flex items-center gap-2">
            <Upload className="w-4 h-4" /> Import
          </button>
          <button onClick={() => window.open('/api/export/orders', '_blank')} className="btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" /> Export
          </button>
          <button onClick={() => setOpen(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" /> New Order
          </button>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
          <input className="input-field pl-10" placeholder="Search orders..." value={search}
            onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load()} />
        </div>
        <select className="input-field w-40" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All Status</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button onClick={load} className="btn-secondary">Filter</button>
      </div>

      <div className="card">
        {loading ? <TableSkeleton /> : orders.length === 0 ? (
          <EmptyState title="No orders yet" description="Create your first order to get started."
            action={() => setOpen(true)} actionLabel="Create Order" />
        ) : (
          <DataTable columns={columns} rows={orders} />
        )}
      </div>

      <OrderFormDialog open={open} onClose={() => setOpen(false)} customers={customers}
        form={form} setForm={setForm} onSubmit={handleCreate} />

      <Dialog open={!!assignOpen} onClose={() => setAssignOpen(null)}>
        <DialogTitle>Assign Worker</DialogTitle>
        <DialogContent>
          {workers.map((w) => (
            <button key={w._id} className="block w-full text-left p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
              onClick={() => assignWorker(assignOpen, w._id)}>
              {w.user?.name} — {w.specialization}
            </button>
          ))}
        </DialogContent>
      </Dialog>

      <Dialog open={importOpen} onClose={() => setImportOpen(false)}>
        <DialogTitle>Import Orders (Excel)</DialogTitle>
        <DialogContent className="pt-4">
          <p className="text-sm text-gray-500 mb-4">Upload .xlsx file for preview. Use export format as template.</p>
          <input type="file" accept=".xlsx,.xls" onChange={handleImport} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
