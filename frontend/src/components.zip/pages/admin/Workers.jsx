import { useEffect, useState } from 'react';
import { Plus } from 'lucide-react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
import DataTable from '../../components/DataTable';
import api from '../../services/api';

export default function AdminWorkers() {
  const [workers, setWorkers] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', specialization: '', experience: 0 });

  const load = () => api.get('/workers').then((r) => setWorkers(r.data || []));
  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    await api.post('/workers', form);
    setOpen(false);
    load();
  };

  const columns = [
    { field: 'name', headerName: 'Name', render: (r) => r.user?.name },
    { field: 'email', headerName: 'Email', render: (r) => r.user?.email },
    { field: 'specialization', headerName: 'Specialization' },
    { field: 'experience', headerName: 'Experience (yrs)' },
    { field: 'isAvailable', headerName: 'Available', render: (r) => r.isAvailable ? 'Yes' : 'No' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between">
        <h1 className="text-2xl font-bold">Workers</h1>
        <button onClick={() => setOpen(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Worker
        </button>
      </div>
      <div className="card">
        <DataTable columns={columns} rows={workers} />
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Worker</DialogTitle>
        <DialogContent className="space-y-3 pt-2">
          {['name', 'email', 'phone', 'specialization'].map((f) => (
            <input key={f} className="input-field" placeholder={f} value={form[f]}
              onChange={(e) => setForm({ ...form, [f]: e.target.value })} />
          ))}
          <input type="number" className="input-field" placeholder="Experience" value={form.experience}
            onChange={(e) => setForm({ ...form, experience: Number(e.target.value) })} />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate}>Create</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
