import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Download } from 'lucide-react';
import DataTable from '../../components/DataTable';
import EmptyState from '../../components/EmptyState';
import { TableSkeleton } from '../../components/Skeleton';
import api from '../../services/api';
import { downloadInvoicePdf } from '../../utils/downloadInvoicePdf';

export default function AdminInvoices() {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/invoices').then((r) => setInvoices(r.data.invoices || [])).finally(() => setLoading(false));
  }, []);

  const columns = [
    {
      field: 'invoiceNumber', headerName: 'Invoice #',
      render: (r) => (
        <button className="text-primary-600 hover:underline" onClick={() => navigate(`/admin/invoices/${r._id}`)}>
          {r.invoiceNumber}
        </button>
      ),
    },
    { field: 'order', headerName: 'Order', render: (r) => r.order?.orderNumber },
    { field: 'customer', headerName: 'Customer', render: (r) => r.customer?.user?.name },
    { field: 'total', headerName: 'Total', render: (r) => `₹${r.total}` },
    { field: 'balanceDue', headerName: 'Balance', render: (r) => `₹${r.balanceDue}` },
    { field: 'status', headerName: 'Status' },
    { field: 'createdAt', headerName: 'Date', render: (r) => new Date(r.createdAt).toLocaleDateString() },
    {
      field: 'pdf', headerName: 'PDF', sortable: false,
      render: (r) => (
        <button className="text-primary-600 flex items-center gap-1 text-sm"
          onClick={() => api.get(`/invoices/${r._id}`).then((res) => downloadInvoicePdf(res.data))}>
          <Download className="w-4 h-4" /> PDF
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Invoices</h1>
      <div className="card">
        {loading ? <TableSkeleton /> : invoices.length === 0 ? (
          <EmptyState title="No invoices yet" description="Generate invoices from the Orders page using the Bill button." />
        ) : (
          <DataTable columns={columns} rows={invoices} />
        )}
      </div>
    </div>
  );
}
