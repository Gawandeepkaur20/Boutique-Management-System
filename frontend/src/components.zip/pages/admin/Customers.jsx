import { useEffect, useState } from 'react';
import { Plus, Download, Search, Upload } from 'lucide-react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
import DataTable from '../../components/DataTable';
import EmptyState from '../../components/EmptyState';
import { TableSkeleton } from '../../components/Skeleton';
import api from '../../services/api';
import { showSuccess, showError } from '../../utils/toast';

export default function AdminCustomers() {
  const [customers, setCustomers] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: 'customer123', city: '' });

  const load = () => {
    setLoading(true);
    const params = search ? `?search=${search}` : '';
    api.get(`/customers${params}`)
      .then((r) => setCustomers(r.data.customers || []))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    try {
      await api.post('/customers', form);
      showSuccess('Customer created');
      setOpen(false);
      load();
    } catch (err) {
      showError(err.response?.data?.message || 'Failed');
    }
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const { data } = await api.post('/export/import/customers', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      showSuccess(`Created ${data.created}, skipped ${data.skipped}`);
      load();
    } catch {
      showError('Import failed');
    }
  };

  const columns = [
    { field: 'name', headerName: 'Name', render: (r) => r.user?.name },
    { field: 'email', headerName: 'Email', render: (r) => r.user?.email },
    { field: 'phone', headerName: 'Phone', render: (r) => r.user?.phone },
    { field: 'city', headerName: 'City' },
    { field: 'createdAt', headerName: 'Joined', render: (r) => new Date(r.createdAt).toLocaleDateString() },
  ];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h1 className="text-2xl font-bold">Customers</h1>
        <div className="flex gap-2">
          <label className="btn-secondary flex items-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4" /> Import
            <input type="file" accept=".xlsx,.xls" className="hidden" onChange={handleImport} />
          </label>
          <button onClick={() => window.open('/api/export/customers', '_blank')} className="btn-secondary flex items-center gap-2">
            <Download className="w-4 h-4" /> Export
          </button>
          <button onClick={() => setOpen(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-4 h-4" /> Add Customer
          </button>
        </div>
      </div>

      <div className="flex gap-2">
        <input className="input-field flex-1" placeholder="Search..." value={search}
          onChange={(e) => setSearch(e.target.value)} />
        <button onClick={load} className="btn-secondary"><Search className="w-4 h-4" /></button>
      </div>

      <div className="card">
        {loading ? <TableSkeleton /> : customers.length === 0 ? (
          <EmptyState title="No customers" description="Add customers manually or import from Excel."
            action={() => setOpen(true)} actionLabel="Add Customer" />
        ) : (
          <DataTable columns={columns} rows={customers} />
        )}
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Customer</DialogTitle>
        <DialogContent className="space-y-3 pt-2">
          {['name', 'email', 'phone', 'city'].map((f) => (
            <input key={f} className="input-field" placeholder={f} value={form[f]}
              onChange={(e) => setForm({ ...form, [f]: e.target.value })} />
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleCreate}>Create</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
