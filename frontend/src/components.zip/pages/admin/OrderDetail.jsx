import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@mui/material';
import StatusBadge from '../../components/StatusBadge';
import { PageSkeleton } from '../../components/Skeleton';
import api from '../../services/api';
import { showSuccess, showError } from '../../utils/toast';

const STATUSES = ['received', 'processing', 'stitching', 'ready', 'delivered'];

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    api.get(`/orders/${id}`).then((r) => setOrder(r.data)).finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    api.get('/workers').then((r) => setWorkers(r.data || []));
  }, [id]);

  const updateStatus = async (status) => {
    await api.patch(`/orders/${id}/status`, { status });
    showSuccess('Status updated');
    load();
  };

  const assignWorker = async (workerId) => {
    await api.patch(`/orders/${id}/assign`, { workerId });
    showSuccess('Worker assigned');
    load();
  };

  const generateBill = async () => {
    try {
      await api.post(`/orders/${id}/invoice`);
      showSuccess('Invoice generated and email sent');
    } catch {
      showError('Failed to generate invoice');
    }
  };

  if (loading) return <PageSkeleton />;
  if (!order) return <p className="text-red-500">Order not found</p>;

  const steps = STATUSES;
  const currentIdx = steps.indexOf(order.status);

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center gap-4">
        <Link to="/admin/orders" className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">{order.orderNumber}</h1>
          <StatusBadge status={order.status} />
        </div>
      </div>

      <div className="card">
        <h3 className="font-semibold mb-4">Status Timeline</h3>
        <div className="flex justify-between relative">
          <div className="absolute top-4 left-0 right-0 h-0.5 bg-gray-200 dark:bg-gray-600" />
          {steps.map((step, i) => (
            <div key={step} className="relative flex flex-col items-center z-10">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                i <= currentIdx ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-600'
              }`}>{i + 1}</div>
              <span className="text-xs mt-2 capitalize">{step}</span>
            </div>
          ))}
        </div>
        <select className="input-field mt-4 max-w-xs" value={order.status}
          onChange={(e) => updateStatus(e.target.value)}>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-semibold mb-3">Customer</h3>
          <p className="font-medium">{order.customer?.user?.name}</p>
          <p className="text-sm text-gray-500">{order.customer?.user?.email}</p>
          <p className="text-sm text-gray-500">{order.customer?.user?.phone}</p>
        </div>
        <div className="card">
          <h3 className="font-semibold mb-3">Worker</h3>
          <p>{order.worker?.user?.name || 'Unassigned'}</p>
          <select className="input-field mt-2" value={order.worker?._id || ''}
            onChange={(e) => e.target.value && assignWorker(e.target.value)}>
            <option value="">Assign worker...</option>
            {workers.map((w) => (
              <option key={w._id} value={w._id}>{w.user?.name}</option>
            ))}
          </select>
        </div>
      </div>

      {order.measurement && (
        <div className="card">
          <h3 className="font-semibold mb-3">Measurements</h3>
          <div className="grid grid-cols-4 gap-2 text-sm">
            {['height', 'chest', 'waist', 'shoulder', 'sleeveLength'].map((k) =>
              order.measurement[k] != null && (
                <div key={k}><span className="text-gray-500 capitalize">{k}:</span> {order.measurement[k]}</div>
              )
            )}
          </div>
        </div>
      )}

      <div className="card">
        <h3 className="font-semibold mb-3">Items</h3>
        {order.items?.map((item, i) => (
          <div key={i} className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700 last:border-0">
            <span>{item.name} {item.fabric && `(${item.fabric})`} x{item.quantity}</span>
            <span>₹{item.quantity * item.price}</span>
          </div>
        ))}
        <p className="text-right font-bold mt-3">Total: ₹{order.totalAmount}</p>
        <p className="text-right text-sm text-gray-500">Advance: ₹{order.advancePaid || 0}</p>
      </div>

      {order.workerNotes && (
        <div className="card">
          <h3 className="font-semibold mb-2">Worker Notes</h3>
          <p className="text-sm">{order.workerNotes}</p>
          {order.completedWorkDetails && <p className="text-sm mt-2">{order.completedWorkDetails}</p>}
        </div>
      )}

      <div className="flex gap-3">
        <Button variant="contained" onClick={generateBill}>Generate Invoice</Button>
        <Button variant="outlined" onClick={() => navigate('/admin/invoices')}>View Invoices</Button>
      </div>
    </div>
  );
}
