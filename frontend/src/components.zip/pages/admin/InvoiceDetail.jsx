import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Download } from 'lucide-react';
import { PageSkeleton } from '../../components/Skeleton';
import api from '../../services/api';
import { downloadInvoicePdf } from '../../utils/downloadInvoicePdf';

export default function InvoiceDetail() {
  const { id } = useParams();
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/invoices/${id}`).then((r) => setInvoice(r.data)).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <PageSkeleton />;
  if (!invoice) return <p className="text-red-500">Invoice not found</p>;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/admin/invoices" className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-2xl font-bold">{invoice.invoiceNumber}</h1>
        </div>
        <button onClick={() => downloadInvoicePdf(invoice)} className="btn-primary flex items-center gap-2">
          <Download className="w-4 h-4" /> Download PDF
        </button>
      </div>

      <div className="card space-y-4" id="invoice-print">
        <div className="flex justify-between">
          <div>
            <p className="text-sm text-gray-500">Boutique Management</p>
            <p className="font-semibold mt-2">Bill To: {invoice.customer?.user?.name}</p>
            <p className="text-sm">{invoice.customer?.user?.email}</p>
          </div>
          <div className="text-right text-sm">
            <p>Date: {new Date(invoice.createdAt).toLocaleDateString()}</p>
            <p>Order: {invoice.order?.orderNumber}</p>
            <p className="capitalize">Status: {invoice.status}</p>
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 dark:border-gray-600">
              <th className="text-left py-2">Description</th>
              <th className="text-right py-2">Qty</th>
              <th className="text-right py-2">Amount</th>
            </tr>
          </thead>
          <tbody>
            {invoice.items?.map((item, i) => (
              <tr key={i} className="border-b border-gray-100 dark:border-gray-700">
                <td className="py-2">{item.description}</td>
                <td className="text-right">{item.quantity}</td>
                <td className="text-right">₹{item.amount}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="text-right space-y-1 text-sm">
          <p>Subtotal: ₹{invoice.subtotal}</p>
          <p>Tax: ₹{invoice.tax || 0}</p>
          <p>Discount: ₹{invoice.discount || 0}</p>
          <p className="text-lg font-bold">Total: ₹{invoice.total}</p>
          <p>Paid: ₹{invoice.amountPaid || 0}</p>
          <p className="text-primary-600 font-semibold">Balance Due: ₹{invoice.balanceDue}</p>
        </div>
      </div>
    </div>
  );
}
