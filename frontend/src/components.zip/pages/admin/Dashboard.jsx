import { useEffect, useState } from 'react';
import { BarChart3, TrendingUp } from 'lucide-react';
import { ShoppingBag, Package, Truck, Users, Wrench, IndianRupee, Inbox } from 'lucide-react';
import StatCard from '../../components/StatCard';
import OrderPieChart from '../../components/OrderPieChart';
import MonthlyChartCard, { MonthlyOrdersChart, MonthlyRevenueChart } from '../../components/MonthlyChartCard';
import OnboardingHint from '../../components/OnboardingHint';
import { StatCardSkeleton, ChartSkeleton } from '../../components/Skeleton';
import { showError } from '../../utils/toast';
import api from '../../services/api';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const PIE_COLORS = ['#3b82f6', '#eab308', '#f97316', '#a855f7', '#22c55e'];

const STATUS_COLORS = {
  received: '#3b82f6',
  processing: '#eab308',
  stitching: '#f97316',
  ready: '#a855f7',
  delivered: '#22c55e',
};

const buildReceivedDeliveredPie = (stats) => {
  const inProgress = Math.max(
    0,
    stats.totalOrders - stats.receivedOrders - stats.deliveredOrders
  );
  return [
    { name: 'Received', value: stats.receivedOrders, color: STATUS_COLORS.received },
    { name: 'Delivered', value: stats.deliveredOrders, color: STATUS_COLORS.delivered },
    { name: 'In Progress', value: inProgress, color: '#f97316' },
  ];
};

const buildReceivedDeliveredOnlyPie = (stats) => [
  { name: 'Orders Received', value: stats.receivedOrders, color: STATUS_COLORS.received },
  { name: 'Orders Delivered', value: stats.deliveredOrders, color: STATUS_COLORS.delivered },
];

const formatChartData = (data, valueKey = 'count') =>
  data.map((d) => ({
    name: `${MONTHS[(d._id?.month || 1) - 1]} ${d._id?.year || ''}`,
    value: d[valueKey] || d.count || 0,
  }));

const presets = {
  week: () => {
    const to = new Date();
    const from = new Date();
    from.setDate(from.getDate() - 7);
    return { from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) };
  },
  month: () => {
    const to = new Date();
    const from = new Date(to.getFullYear(), to.getMonth(), 1);
    return { from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) };
  },
  all: () => ({ from: '', to: '' }),
};

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(presets.all());

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (range.from) params.set('from', range.from);
    if (range.to) params.set('to', range.to);
    api.get(`/dashboard/stats?${params}`)
      .then((res) => setData(res.data))
      .catch((err) => {
        setData(null);
        showError(err.response?.data?.message || 'Could not load dashboard. Is the backend running?');
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [range.from, range.to]);

  const monthlyOrders = data ? formatChartData(data.charts.monthlyOrders) : [];
  const monthlyRevenue = data ? formatChartData(data.charts.monthlyRevenue, 'revenue') : [];
  const statusPie =
    data?.charts.statusDistribution.map((s) => ({
      name: s._id,
      value: s.count,
      color: STATUS_COLORS[s._id] || PIE_COLORS[0],
    })) || [];

  const receivedDeliveredPie = data ? buildReceivedDeliveredPie(data.stats) : [];
  const receivedDeliveredOnlyPie = data ? buildReceivedDeliveredOnlyPie(data.stats) : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-4">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="flex flex-wrap gap-2 items-center">
          {['week', 'month', 'all'].map((p) => (
            <button key={p} onClick={() => setRange(presets[p]())}
              className="px-3 py-1.5 text-sm rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 hover:border-primary-400 capitalize">
              {p === 'all' ? 'All time' : `This ${p}`}
            </button>
          ))}
          <input type="date" className="input-field w-auto text-sm" value={range.from}
            onChange={(e) => setRange({ ...range, from: e.target.value })} />
          <input type="date" className="input-field w-auto text-sm" value={range.to}
            onChange={(e) => setRange({ ...range, to: e.target.value })} />
        </div>
      </div>

      <OnboardingHint id="admin-dashboard">
        Monthly orders and revenue charts show trends over time. Use date filters for stat cards and pie charts.
      </OnboardingHint>

      {loading ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 7 }).map((_, i) => <StatCardSkeleton key={i} />)}
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <ChartSkeleton />
            <ChartSkeleton />
          </div>
        </>
      ) : !data ? (
        <div className="card text-center py-12">
          <p className="text-red-500 font-medium">Failed to load dashboard</p>
          <p className="text-sm text-gray-500 mt-2">Restart the backend and refresh.</p>
          <button onClick={load} className="btn-primary mt-4">Retry</button>
        </div>
      ) : (
        <>
          {/* Stat cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard title="Total Orders" value={data.stats.totalOrders} icon={ShoppingBag} color="primary" />
            <StatCard title="Orders Received" value={data.stats.receivedOrders} icon={Inbox} color="blue" />
            <StatCard title="Processing" value={data.stats.processingOrders} icon={Package} color="orange" />
            <StatCard title="Delivered" value={data.stats.deliveredOrders} icon={Truck} color="green" />
            <StatCard title="Customers" value={data.stats.totalCustomers} icon={Users} color="purple" />
            <StatCard title="Workers" value={data.stats.totalWorkers} icon={Wrench} color="blue" />
            <StatCard title="Revenue" value={`₹${data.stats.revenue?.toLocaleString()}`} icon={IndianRupee} color="green" />
          </div>

          {/* Monthly charts — primary section */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="w-5 h-5 text-primary-600" />
              <h2 className="text-lg font-semibold">Monthly Analytics</h2>
            </div>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <MonthlyChartCard
                title="Monthly Orders"
                subtitle="Number of orders placed per month"
              >
                <MonthlyOrdersChart data={monthlyOrders} />
              </MonthlyChartCard>

              <MonthlyChartCard
                title="Monthly Revenue"
                subtitle="Total invoice revenue per month (₹)"
              >
                <div className="flex items-start gap-2 mb-2 text-xs text-green-600 dark:text-green-400">
                  <TrendingUp className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>Based on generated invoices</span>
                </div>
                <MonthlyRevenueChart data={monthlyRevenue} />
              </MonthlyChartCard>
            </div>
          </section>

          {/* Pie charts */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Order Distribution</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              <OrderPieChart
                title="Orders Received vs Delivered"
                data={receivedDeliveredOnlyPie}
                height={280}
                emptyMessage="No received or delivered orders yet"
              />
              <OrderPieChart
                title="Received · In Progress · Delivered"
                data={receivedDeliveredPie}
                height={280}
                emptyMessage="No orders in range"
              />
              <OrderPieChart
                title="All Order Statuses"
                data={statusPie}
                height={280}
                emptyMessage="No orders in range"
              />
            </div>
          </section>
        </>
      )}
    </div>
  );
}
