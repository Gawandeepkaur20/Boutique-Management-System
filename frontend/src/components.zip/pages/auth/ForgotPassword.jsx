import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Scissors } from 'lucide-react';
import { Alert } from '@mui/material';
import api from '../../services/api';
import { showSuccess } from '../../utils/toast';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [devToken, setDevToken] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/auth/forgot-password', { email });
      setMessage(data.message);
      if (data.resetToken) setDevToken(data.resetToken);
      showSuccess('Check your email for reset instructions');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Request failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-purple-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="card w-full max-w-md">
        <div className="text-center mb-6">
          <Scissors className="w-10 h-10 text-primary-600 mx-auto mb-2" />
          <h1 className="text-xl font-bold">Forgot Password</h1>
          <p className="text-sm text-gray-500 mt-1">Custom tailoring, simplified</p>
        </div>

        {message && <Alert severity="info" className="mb-4">{message}</Alert>}
        {devToken && (
          <Alert severity="warning" className="mb-4 text-xs">
            Dev reset link: <Link to={`/reset-password/${devToken}`} className="underline">Reset password</Link>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="email" className="input-field" placeholder="Your email" value={email}
            onChange={(e) => setEmail(e.target.value)} required />
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Sending...' : 'Send Reset Link'}
          </button>
        </form>

        <p className="text-center mt-4 text-sm">
          <Link to="/login" className="text-primary-600 hover:underline">Back to login</Link>
        </p>
      </div>
    </div>
  );
}
