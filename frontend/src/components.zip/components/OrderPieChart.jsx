import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const renderLabel = ({ name, value, percent }) =>
  value > 0 ? `${name}: ${value} (${(percent * 100).toFixed(0)}%)` : '';

export default function OrderPieChart({ title, data, height = 300, emptyMessage = 'No order data' }) {
  const filtered = (data || []).filter((d) => d.value > 0);
  const total = filtered.reduce((sum, d) => sum + d.value, 0);

  return (
    <div className="card">
      <h3 className="font-semibold mb-1">{title}</h3>
      {total > 0 && (
        <p className="text-sm text-gray-500 mb-4">Total orders: {total}</p>
      )}
      {filtered.length === 0 ? (
        <p className="text-gray-500 text-sm py-20 text-center">{emptyMessage}</p>
      ) : (
        <ResponsiveContainer width="100%" height={height}>
          <PieChart>
            <Pie
              data={filtered}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={90}
              paddingAngle={2}
              label={renderLabel}
              labelLine={{ strokeWidth: 1 }}
            >
              {filtered.map((entry, i) => (
                <Cell key={entry.name || i} fill={entry.color} stroke="transparent" />
              ))}
            </Pie>
            <Tooltip
              formatter={(value, name) => [value, name]}
              contentStyle={{
                borderRadius: '8px',
                border: '1px solid #e5e7eb',
              }}
            />
            <Legend
              verticalAlign="bottom"
              formatter={(value, entry) => (
                <span className="text-sm capitalize">{value}: {entry.payload?.value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
