import { Plus, Trash2 } from 'lucide-react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button,
  MenuItem, Select, FormControl, InputLabel,
} from '@mui/material';

const emptyItem = { name: '', quantity: 1, price: 0, fabric: '' };

export default function OrderFormDialog({ open, onClose, customers, form, setForm, onSubmit }) {
  const addItem = () => setForm({ ...form, items: [...form.items, { ...emptyItem }] });
  const removeItem = (i) => setForm({ ...form, items: form.items.filter((_, idx) => idx !== i) });
  const updateItem = (i, field, value) => {
    const items = [...form.items];
    items[i] = { ...items[i], [field]: field === 'quantity' || field === 'price' ? Number(value) : value };
    setForm({ ...form, items });
  };

  const total = form.items.reduce((s, i) => s + (i.quantity || 0) * (i.price || 0), 0);

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>Create Order</DialogTitle>
      <DialogContent className="space-y-4 pt-2">
        <FormControl fullWidth>
          <InputLabel>Customer</InputLabel>
          <Select value={form.customerId} label="Customer"
            onChange={(e) => setForm({ ...form, customerId: e.target.value })}>
            {customers.map((c) => (
              <MenuItem key={c._id} value={c._id}>{c.user?.name}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <div className="grid grid-cols-2 gap-3">
          <select className="input-field" value={form.priority}
            onChange={(e) => setForm({ ...form, priority: e.target.value })}>
            <option value="low">Low Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="high">High Priority</option>
          </select>
          <input type="date" className="input-field" value={form.deliveryDate || ''}
            onChange={(e) => setForm({ ...form, deliveryDate: e.target.value })} />
          <input type="number" className="input-field" placeholder="Advance paid" value={form.advancePaid}
            onChange={(e) => setForm({ ...form, advancePaid: Number(e.target.value) })} />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h4 className="font-medium text-sm">Line Items</h4>
            <button type="button" onClick={addItem} className="text-primary-600 text-sm flex items-center gap-1">
              <Plus className="w-4 h-4" /> Add item
            </button>
          </div>
          {form.items.map((item, i) => (
            <div key={i} className="grid grid-cols-12 gap-2 items-center">
              <input className="input-field col-span-4" placeholder="Item name" value={item.name}
                onChange={(e) => updateItem(i, 'name', e.target.value)} />
              <input className="input-field col-span-2" type="number" placeholder="Qty" value={item.quantity}
                onChange={(e) => updateItem(i, 'quantity', e.target.value)} />
              <input className="input-field col-span-2" type="number" placeholder="Price" value={item.price}
                onChange={(e) => updateItem(i, 'price', e.target.value)} />
              <input className="input-field col-span-3" placeholder="Fabric" value={item.fabric || ''}
                onChange={(e) => updateItem(i, 'fabric', e.target.value)} />
              {form.items.length > 1 && (
                <button type="button" onClick={() => removeItem(i)} className="col-span-1 text-red-500">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
          <p className="text-right font-semibold">Total: ₹{total}</p>
        </div>

        <textarea className="input-field" rows={2} placeholder="Notes" value={form.notes || ''}
          onChange={(e) => setForm({ ...form, notes: e.target.value })} />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={onSubmit} disabled={!form.customerId || !form.items[0]?.name}>
          Create Order
        </Button>
      </DialogActions>
    </Dialog>
  );
}
