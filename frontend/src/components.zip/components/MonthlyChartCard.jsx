import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts';

export function MonthlyOrdersChart({ data, height = 320 }) {
  if (!data?.length) {
    return (
      <p className="text-gray-500 text-sm py-24 text-center">
        No monthly order data yet. Create orders to see this chart.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" opacity={0.3} vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
        <Tooltip
          formatter={(value) => [value, 'Orders']}
          contentStyle={{ borderRadius: 8 }}
        />
        <Bar dataKey="value" name="Orders" fill="#c026d3" radius={[6, 6, 0, 0]} maxBarSize={48} />
        <Legend />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function MonthlyRevenueChart({ data, height = 320 }) {
  if (!data?.length) {
    return (
      <p className="text-gray-500 text-sm py-24 text-center">
        No monthly revenue data yet. Generate invoices to see this chart.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" opacity={0.3} vertical={false} />
        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
        <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`} />
        <Tooltip
          formatter={(value) => [`₹${Number(value).toLocaleString()}`, 'Revenue']}
          contentStyle={{ borderRadius: 8 }}
        />
        <Line
          type="monotone"
          dataKey="value"
          name="Revenue"
          stroke="#22c55e"
          strokeWidth={3}
          dot={{ r: 4, fill: '#22c55e' }}
          activeDot={{ r: 6 }}
        />
        <Legend />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default function MonthlyChartCard({ title, subtitle, children }) {
  return (
    <div className="card h-full flex flex-col">
      <div className="mb-4">
        <h3 className="font-semibold text-lg">{title}</h3>
        {subtitle && <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex-1 min-h-[320px]">{children}</div>
    </div>
  );
}
