import { NavLink, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../../redux/slices/authSlice';
import { toggleTheme } from '../../redux/slices/themeSlice';
import {
  LayoutDashboard, ShoppingBag, Users, Wrench, FileText, LogOut, Sun, Moon, Scissors, Ruler, ListTodo,
} from 'lucide-react';

const roleColors = {
  admin: 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300',
  customer: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300',
  worker: 'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300',
};

const dashboardHome = { admin: '/admin/dashboard', worker: '/worker', customer: '/customer/dashboard' };

const Sidebar = ({ links, title, onNavigate }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((s) => s.auth);
  const { mode } = useSelector((s) => s.theme);
  const homePath = dashboardHome[user?.role] || '/';

  const icons = {
    LayoutDashboard, ShoppingBag, Users, Wrench, FileText, Scissors, Ruler, ListTodo,
  };

  return (
    <aside className="w-64 min-h-screen bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <button
          type="button"
          onClick={() => { navigate(homePath); onNavigate?.(); }}
          className="flex items-center gap-2 w-full text-left hover:opacity-80 transition-opacity"
        >
          <Scissors className="w-8 h-8 text-primary-600 shrink-0" />
          <div>
            <h1 className="font-bold text-lg">{title}</h1>
            <p className="text-xs text-gray-500">Boutique System</p>
          </div>
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {links.map(({ to, label, icon, end: linkEnd }) => {
          const Icon = icons[icon] || LayoutDashboard;
          return (
            <NavLink
              key={to}
              to={to}
              onClick={onNavigate}
              end={linkEnd ?? (to.endsWith('/admin') || to.endsWith('/customer') || to.endsWith('/worker'))}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 font-medium'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <Icon className="w-5 h-5" />
              {label}
            </NavLink>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-200 dark:border-gray-700 space-y-3">
        <div className="flex items-center gap-3 px-2">
          <div className="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold shrink-0">
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-sm truncate">{user?.name}</p>
            <span className={`inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium capitalize ${roleColors[user?.role] || ''}`}>
              {user?.role}
            </span>
          </div>
        </div>

        <button
          onClick={() => dispatch(toggleTheme())}
          className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {mode === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          {mode === 'dark' ? 'Light Mode' : 'Dark Mode'}
        </button>
        <button
          onClick={() => dispatch(logout())}
          className="flex items-center gap-3 w-full px-4 py-2 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
