import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Sidebar from './Sidebar';
import TopBar from './TopBar';

export default function AppShell({ links, title, gradient = false }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden
        />
      )}

      <div
        className={`fixed lg:static inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <Sidebar links={links} title={title} onNavigate={() => setSidebarOpen(false)} />
        <button
          className="lg:hidden absolute top-4 right-[-3rem] p-2 bg-white dark:bg-gray-800 rounded-lg shadow"
          onClick={() => setSidebarOpen(false)}
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onMenuClick={() => setSidebarOpen(true)} />
        <main
          className={`flex-1 p-4 md:p-6 overflow-auto ${
            gradient
              ? 'bg-gradient-to-br from-primary-50/80 via-white to-purple-50/50 dark:from-gray-900 dark:via-gray-900 dark:to-purple-950/30'
              : ''
          }`}
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
}
