import { useSelector } from 'react-redux';
import { Menu } from 'lucide-react';
import NotificationDropdown from '../NotificationDropdown';
import GlobalSearch from '../GlobalSearch';

export default function TopBar({ onMenuClick }) {
  const { user } = useSelector((s) => s.auth);

  return (
    <header className="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 md:px-6 gap-4">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <h2 className="text-base md:text-lg font-semibold text-gray-700 dark:text-gray-200 truncate">
          Welcome, {user?.name}
        </h2>
      </div>
      <div className="flex items-center gap-2 md:gap-4 shrink-0">
        <GlobalSearch />
        <NotificationDropdown />
      </div>
    </header>
  );
}
