import AppShell from './AppShell';

const customerLinks = [
  { to: '/customer/dashboard', label: 'Dashboard', icon: 'LayoutDashboard', end: true },
  { to: '/customer/profile', label: 'Profile', icon: 'Users' },
  { to: '/customer/measurements', label: 'Measurements', icon: 'Ruler' },
  { to: '/customer/orders', label: 'My Orders', icon: 'ShoppingBag' },
  { to: '/customer/track', label: 'Track Order', icon: 'ListTodo' },
];

export default function CustomerLayout() {
  return <AppShell links={customerLinks} title="My Boutique" />;
}
