import AppShell from './AppShell';

const adminLinks = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: 'LayoutDashboard', end: true },
  { to: '/admin/orders', label: 'Orders', icon: 'ShoppingBag' },
  { to: '/admin/customers', label: 'Customers', icon: 'Users' },
  { to: '/admin/workers', label: 'Workers', icon: 'Wrench' },
  { to: '/admin/invoices', label: 'Invoices', icon: 'FileText' },
];

export default function AdminLayout() {
  return <AppShell links={adminLinks} title="Boutique Admin" gradient />;
}
